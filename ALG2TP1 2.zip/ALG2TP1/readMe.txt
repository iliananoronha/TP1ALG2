A totalidade dos arquivos foi postada no gitHub no link: 
Para cada exemplo foi postados o documento original e o arquivo comprimido.
Inclui-se aqui também os arquivos fonte e a documentação apesar de também estarem presentes no repositório. 
